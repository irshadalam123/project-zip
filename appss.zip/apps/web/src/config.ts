export const appName = import.meta.env.VITE_APP_NAME || 'Aether';
export const apiBaseUrl = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
export const frontendUrl = import.meta.env.VITE_FRONTEND_URL || 'http://localhost:5173';

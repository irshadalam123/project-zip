"""Domain models.

These Pydantic models are the application's persistence-agnostic records.
TODO(postgres): add SQLAlchemy ORM mappings under ``app/models/orm`` and
translate them at the repository boundary. Do not import ORM types into
services or routes.
"""

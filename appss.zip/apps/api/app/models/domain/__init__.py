"""Domain entities shared by services and repositories."""

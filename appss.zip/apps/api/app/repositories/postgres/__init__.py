"""PostgreSQL repositories are not implemented.

TODO(postgres): add one SQLAlchemy async repository per interface in this
package, for example ``postgres_user_repository.py``. Select the implementation
inside ``build_container`` when a database URL is configured. Do not open a
connection from this module until that work is done.
"""

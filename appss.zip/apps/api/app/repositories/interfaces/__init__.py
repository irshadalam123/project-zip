"""Persistence ports used by the service layer."""

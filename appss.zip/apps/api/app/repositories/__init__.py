"""Repository interfaces and in-memory implementations.

TODO(postgres): add ``app/repositories/postgres`` modules that implement these
interfaces with SQLAlchemy. Bind the new classes in ``app.core.container``
only. Routes, services, workers, and the automation engine must stay unchanged.
"""

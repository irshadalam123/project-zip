"""External system adapters."""

"""Meta Instagram API adapter.

Services must depend on ``InstagramClient`` and the types in this package.
Do not call Meta URLs from routes, workers, or the automation engine.
"""

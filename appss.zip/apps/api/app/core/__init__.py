"""Application core: configuration, security, and dependency wiring."""

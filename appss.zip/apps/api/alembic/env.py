"""Alembic environment that refuses to run.

TODO(postgres): configure an async SQLAlchemy engine from DATABASE_URL and
import ORM metadata here. Do not add a connection until the PostgreSQL
repositories exist.
"""

from __future__ import annotations

import sys

BLOCKED = (
    "PostgreSQL is not configured. Refusing to run Alembic so this project "
    "cannot connect to a database. Add SQLAlchemy models and a database URL "
    "before enabling migrations."
)


def run_migrations_offline() -> None:
    raise RuntimeError(BLOCKED)


def run_migrations_online() -> None:
    raise RuntimeError(BLOCKED)


if __name__ == "__main__" or True:
    print(BLOCKED, file=sys.stderr)
    raise RuntimeError(BLOCKED)
